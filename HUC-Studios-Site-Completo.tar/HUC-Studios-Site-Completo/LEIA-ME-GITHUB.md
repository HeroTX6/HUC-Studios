# HUC-Studios-Site-Completo

Exportação integral do código da versão salva 25.
Commit: `6fc09722b4fb586ac11b04557fbfd8f14bf5f6ba`.
Arquivos originais: 121.

## Site HUC Studios
Inclui páginas públicas, cinco imagens do portfólio, formulário, notificação por FormSubmit, backend de leads e APIs usadas pelo CRM. As rotas app/api/crm pertencem ao backend do site e não são o painel visual do CRM.

O banco usa o binding DB. O esquema está em db/schema.ts e as quatro migrações SQL estão em drizzle/, de 0000 a 0003. Em uma nova hospedagem, provisione D1, vincule-o como DB e aplique essas migrações em ordem com o mecanismo da hospedagem. O ID de banco no vite.config.ts é um placeholder de desenvolvimento. Este pacote não contém os registros de produção.

O destinatário FormSubmit está em lib/lead-notifications.ts e app/contact-experience.tsx: hucstudios.contato@gmail.com. Revise a URL original em lib/lead-notifications.ts ao mudar de domínio. A ativação e a entrega do serviço externo não são transferidas por este arquivo.

## O que está incluído
Todos os arquivos rastreados no commit original foram preservados byte a byte, incluindo configurações, componentes, testes, scripts, lockfile e metadados de hospedagem. O README original também foi preservado. INVENTARIO-SHA256.txt lista os arquivos originais e seus hashes.

Este é o código-fonte completo, não um backup do serviço hospedado. Não inclui registros de clientes, segredos de produção, histórico Git, dependências instaladas (node_modules), caches ou builds regeneráveis. As dependências estão declaradas em package.json e package-lock.json. Não foram consultados ou exportados os dados do banco.

## Colocar no GitHub
1. Extraia o TAR; dentro dele há uma pasta do projeto.
2. Abra um terminal nessa pasta. Use Git para enviar também os arquivos de configuração que começam com ponto.
3. Execute, substituindo a URL pelo seu repositório vazio:

```bash
git init
git add .
git commit -m "Importa projeto HUC completo"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

## Instalação e execução
O package.json exige Node.js >=22.13.0. Os scripts existentes usam Bash e utilitários Linux (flock, curl e GNU timeout); no Windows, use WSL. Com as ferramentas disponíveis, os comandos originais são:

```bash
npm ci
npm run dev
# compilação, quando necessária:
npm run build
```

Não foi executada nova instalação/build nesta exportação: a verificação foi de integridade dos arquivos em relação ao commit salvo. Esses comandos não provisionam serviços de produção nem migram dados automaticamente.

## Configuração necessária fora de Sites
O projeto usa React, Vinext/Vite, Cloudflare Workers e integrações da plataforma Sites. GitHub armazena o código; GitHub Pages sozinho não executa este backend.

- Preserve a arquitetura de servidor; configure um ambiente compatível com Workers ou adapte o código para a hospedagem escolhida.
- .openai/hosting.json identifica o projeto original e é importado pelo Vite. Foi mantido por completude; seu project_id não é senha nem transfere propriedade/serviços. Revise esse vínculo ao criar outra implantação.
- O login de app/chatgpt-auth.ts depende das rotas /signin-with-chatgpt e /signout-with-chatgpt e dos cabeçalhos de identidade fornecidos pela plataforma. Fora dela, implemente autenticação e sessão verificadas no servidor. Não confie em cabeçalhos de identidade enviados diretamente pelo navegador.
- HUC_CRM_SERVICE_TOKEN é um segredo de servidor compartilhado pelos dois projetos, com pelo menos 32 caracteres. Configure o mesmo valor em ambos através do gerenciador de segredos da hospedagem. Não existe valor real neste pacote. CONFIGURACAO-EXEMPLO.txt contém apenas um campo vazio.
- Se utilizar .dev.vars localmente, acrescente esse nome ao .gitignore ANTES de criá-lo. Não envie segredos ao GitHub. O .gitignore original já exclui .env*.
- O código contém endereços operacionais e permissões originais. Revise-os antes de tornar o repositório público.

## Relação entre os projetos
O site recebe os formulários e possui o banco D1. O CRM consulta as APIs privadas do site usando o token compartilhado. Exportar ou subir os repositórios não copia o banco nem configura login, domínio ou envio de e-mails automaticamente.
