"use client";

import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";

export function ThemeToggle() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const savedTheme = window.localStorage.getItem("huc-theme");
    const isDark = savedTheme !== "light";
    document.documentElement.dataset.theme = isDark ? "dark" : "light";
    const timer = window.setTimeout(() => setDark(isDark), 0);
    return () => window.clearTimeout(timer);
  }, []);

  function changeTheme(enabled: boolean) {
    setDark(enabled);
    document.documentElement.dataset.theme = enabled ? "dark" : "light";
    window.localStorage.setItem("huc-theme", enabled ? "dark" : "light");
  }

  return (
    <label className="theme-control">
      <span aria-hidden="true">{dark ? "☾" : "☀"}</span>
      <span className="theme-label">{dark ? "Escuro" : "Claro"}</span>
      <Switch checked={dark} onCheckedChange={changeTheme} aria-label="Alternar entre modo claro e escuro" />
    </label>
  );
}
