import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HUC Studios — Sua ideia merece presença",
  description: "Conteúdo, identidade visual e estratégia para transformar marcas em presença, comunidade e resultado.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" data-theme="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: `try{const t=localStorage.getItem('huc-theme');document.documentElement.dataset.theme=t==='light'?'light':'dark'}catch(e){}` }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
