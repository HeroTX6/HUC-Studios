# Estrutura do HUC CRM

Atualizado em 03/09/2026.

## 1. Visão geral

O HUC CRM é um painel separado do site público da HUC Studios. Ele foi criado para Hero e seus colaboradores acompanharem cadastros, validarem possíveis leads, definirem responsáveis e registrarem o andamento comercial.

Fluxo principal:

1. O visitante preenche o formulário no site da HUC Studios.
2. O servidor confere os dados obrigatórios e bloqueia envios suspeitos pelo campo antispam.
3. O cadastro é analisado e recebe uma nota de qualidade.
4. O lead é salvo no banco de dados.
5. O CRM consulta os registros pela integração protegida.
6. Um colaborador autorizado pode atualizar status, responsável, validação e anotações.

## 2. Aplicações

| Aplicação | Função | Endereço |
|---|---|---|
| HUC Studios | Site público e entrada dos cadastros | https://hucstudios.herotx6.chatgpt.site |
| HUC CRM | Painel de gestão de leads e equipe | https://huc-crm.herotx6.chatgpt.site |

O visual do site público permanece independente do CRM.

## 3. Telas do CRM

### Oportunidades

Área principal para consultar e trabalhar os leads.

Recursos:

- indicadores de novos contatos, contatos em andamento, qualificados e pendentes de revisão;
- busca por nome, e-mail, empresa, projeto ou responsável;
- filtro por status comercial;
- filtro por resultado da validação;
- filtro por responsável;
- filtro por plano;
- filtro por data;
- ordenação por cadastro, atualização ou qualidade;
- contador de resultados;
- limpeza rápida dos filtros;
- abertura dos detalhes do lead em painel lateral.

### Detalhes do lead

Informações disponíveis:

- nome;
- e-mail;
- empresa ou Instagram;
- descrição do projeto;
- plano escolhido;
- melhor período para contato;
- data de recebimento;
- situação da notificação;
- nota de qualidade;
- alertas encontrados pela análise;
- possível contato duplicado;
- status comercial;
- responsável;
- validação;
- anotações comerciais;
- parecer da validação;
- pessoa que realizou a validação.

### Equipe

Área usada para controlar o acesso de colaboradores.

Recursos:

- cadastro por nome e e-mail da conta ChatGPT;
- escolha do nível de acesso;
- alteração do nível de acesso;
- desativação e reativação de colaboradores;
- identificação de acessos principais protegidos;
- utilização dos colaboradores ativos como responsáveis pelos leads.

## 4. Níveis de acesso

| Nível | Permissões |
|---|---|
| Proprietário | Gerencia leads, validações, responsáveis e equipe. O acesso principal é protegido. |
| Administrador | Gerencia leads, validações, responsáveis e colaboradores. |
| Atendimento | Consulta e atualiza leads, mas não altera os acessos da equipe. |

Acessos preservados na versão atual:

- Hero — `herotx6@gmail.com`;
- HUC Studios — `hucstudios.contato@gmail.com`;
- Erik — `erik.hucstudios@gmail.com`.

## 5. Status utilizados

### Status comercial

| Código interno | Exibição no CRM |
|---|---|
| `novo` | Novo |
| `em_contato` | Em contato |
| `proposta` | Proposta enviada |
| `fechado` | Fechado |
| `arquivado` | Arquivado |

### Validação do lead

| Código interno | Significado |
|---|---|
| `qualificado` | Cadastro com dados suficientes e boa pontuação. |
| `revisar` | Cadastro que precisa de conferência humana. |
| `duplicado` | O e-mail já apareceu em outro cadastro. |
| `descartado` | Lead descartado manualmente pela equipe. |

## 6. Análise automática

Cada novo cadastro começa com 100 pontos. A análise reduz a nota quando encontra situações que merecem atenção.

| Situação encontrada | Ajuste na nota |
|---|---:|
| Nome com apenas uma palavra | -10 |
| Empresa ou Instagram não informado | -10 |
| Descrição do projeto com menos de 35 caracteres | -25 |
| Descrição entre 35 e 69 caracteres | -10 |
| E-mail já cadastrado | -45 |

Classificação automática:

- e-mail repetido: `duplicado`;
- nota igual ou superior a 75: `qualificado`;
- nota abaixo de 75: `revisar`.

O sistema não apaga automaticamente um cadastro duplicado. Ele mantém o registro para a equipe decidir se é um novo pedido do mesmo cliente ou apenas repetição.

## 7. Validação de entrada

O formulário público confere:

- nome com no mínimo dois caracteres;
- formato do e-mail;
- tamanho das partes do e-mail;
- ausência de pontos duplos no endereço;
- descrição do projeto com no mínimo dez caracteres;
- plano pertencente às opções oficiais;
- período pertencente às opções oficiais;
- campo invisível antispam vazio.

Planos aceitos:

- Essencial;
- Profissional;
- Executivo;
- Personalizado.

Períodos aceitos:

- Manhã;
- Tarde;
- Noite;
- Qualquer período.

## 8. Dados armazenados para cada lead

| Campo | Finalidade |
|---|---|
| `id` | Identificador do lead. |
| `name` | Nome do contato. |
| `email` | E-mail normalizado. |
| `company` | Empresa ou Instagram. |
| `project` | Objetivo e descrição do projeto. |
| `plan` | Plano escolhido. |
| `period` | Melhor período para retorno. |
| `status` | Etapa comercial. |
| `assignedTo` | Responsável atual. |
| `notes` | Anotações comerciais. |
| `source` | Origem do cadastro. |
| `qualityScore` | Nota automática de zero a cem. |
| `validationStatus` | Resultado da validação. |
| `validationDetails` | Alertas encontrados automaticamente. |
| `validationNotes` | Parecer escrito pela equipe. |
| `duplicateOfId` | Referência ao cadastro anterior com o mesmo e-mail. |
| `validatedAt` | Data da revisão manual. |
| `validatedBy` | E-mail de quem fez a revisão. |
| `notificationStatus` | Situação da notificação. |
| `notificationError` | Erro da notificação, quando houver. |
| `notifiedAt` | Data de envio da notificação. |
| `createdAt` | Data de criação. |
| `updatedAt` | Data da última alteração. |

## 9. Dados armazenados para colaboradores

| Campo | Finalidade |
|---|---|
| `id` | Identificador do colaborador. |
| `name` | Nome exibido no CRM. |
| `email` | E-mail usado no login com ChatGPT. |
| `role` | Proprietário, administrador ou atendimento. |
| `active` | Indica se o acesso está ativo. |
| `createdAt` | Data de cadastro. |
| `updatedAt` | Data da última alteração. |

## 10. Segurança e autorização

- O CRM inicia o login pela autenticação do ChatGPT.
- O e-mail autenticado é conferido no servidor.
- Colaboradores desativados não entram no painel.
- As APIs do CRM repetem a verificação de autorização; esconder um botão não é usado como mecanismo de segurança.
- A comunicação entre o CRM e o site utiliza a variável secreta `HUC_CRM_SERVICE_TOKEN`.
- A chave real não está incluída neste pacote.
- A validação registra no servidor o e-mail da pessoa que fez a revisão.
- Os dados dos leads não são enviados diretamente do navegador para a API privada do site público.

## 11. Endpoints principais

### No site HUC Studios

| Método e rota | Função |
|---|---|
| `POST /api/leads` | Recebe, valida, analisa e salva o cadastro. |
| `POST /api/leads/notification` | Trata a notificação de um novo cadastro. |
| `GET /api/crm/leads` | Entrega os leads ao CRM autenticado pelo serviço. |
| `PATCH /api/crm/leads` | Atualiza andamento, responsável e validação. |
| `GET /api/crm/session` | Confere se um e-mail pode acessar o CRM. |
| `GET /api/crm/collaborators` | Lista a equipe. |
| `POST /api/crm/collaborators` | Adiciona ou reativa um colaborador. |
| `PATCH /api/crm/collaborators` | Altera função ou situação do colaborador. |

### No HUC CRM

| Método e rota | Função |
|---|---|
| `GET /api/admin/leads` | Consulta protegida dos leads. |
| `PATCH /api/admin/leads` | Atualização protegida de um lead. |
| `GET /api/admin/collaborators` | Consulta protegida da equipe. |
| `POST /api/admin/collaborators` | Adição permitida para proprietário ou administrador. |
| `PATCH /api/admin/collaborators` | Alteração permitida para proprietário ou administrador. |

## 12. Organização dos arquivos

### Painel `huc-crm`

```text
huc-crm/
├── .openai/hosting.json
├── app/
│   ├── api/admin/
│   │   ├── collaborators/route.ts
│   │   └── leads/route.ts
│   ├── chatgpt-auth.ts
│   ├── crm-dashboard.tsx
│   ├── crm.css
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/ui/
├── hooks/
├── lib/
│   ├── admin-auth.ts
│   ├── huc-api.ts
│   └── utils.ts
├── public/
├── tests/
├── worker/
├── package.json
├── package-lock.json
├── tsconfig.json
└── vite.config.ts
```

### Integração `integracao-hucstudios`

```text
integracao-hucstudios/
├── .openai/hosting.json
├── app/api/
│   ├── crm/
│   │   ├── collaborators/route.ts
│   │   ├── leads/route.ts
│   │   └── session/route.ts
│   └── leads/
│       ├── notification/route.ts
│       └── route.ts
├── db/
│   ├── index.ts
│   └── schema.ts
├── drizzle/
│   ├── migrations SQL
│   └── meta/
├── lib/
│   ├── crm-members.ts
│   ├── crm-service-auth.ts
│   └── lead-notifications.ts
├── drizzle.config.ts
├── package.json
└── tsconfig.json
```

## 13. Tecnologias

- React;
- TypeScript;
- Next.js compatível com Vinext;
- Cloudflare Workers;
- Cloudflare D1 com SQLite;
- Drizzle ORM e migrações SQL;
- autenticação do ChatGPT fornecida pela plataforma;
- CSS responsivo personalizado para desktop e celular.

## 14. Observações para manutenção

- Novas alterações no banco devem gerar uma nova migração; migrações já publicadas não devem ser reescritas.
- O valor de `HUC_CRM_SERVICE_TOKEN` deve existir nos dois projetos e permanecer secreto.
- O nome de um colaborador ativo é usado como opção de responsável pelo lead.
- Os proprietários principais funcionam também como acesso de recuperação.
- O CRM e o site devem continuar publicados como projetos separados.
