# HUC CRM — estrutura completa

Este pacote reúne o código-fonte do painel HUC CRM e os arquivos responsáveis pela integração com o site da HUC Studios.

## Conteúdo do pacote

- `huc-crm/`: painel separado usado por Hero e pelos colaboradores.
- `integracao-hucstudios/`: banco de dados, recebimento dos formulários, análise dos leads e comunicação protegida com o CRM.
- `ESTRUTURA_DO_CRM.md`: documentação funcional e técnica do sistema.

## Endereços atuais

- CRM: https://huc-crm.herotx6.chatgpt.site
- Site público: https://hucstudios.herotx6.chatgpt.site

O site público e o CRM são aplicações separadas. O site recebe o cadastro do possível cliente e envia os dados ao banco. O CRM consulta esse banco usando uma conexão protegida.

## Segurança

O pacote não contém senhas nem o valor da chave privada usada na comunicação entre os dois sistemas. O acesso ao CRM depende do login com ChatGPT e da autorização do e-mail no próprio CRM.
