import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HUC CRM",
  description: "Painel privado para gestão de leads e atendimentos da HUC Studios.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
