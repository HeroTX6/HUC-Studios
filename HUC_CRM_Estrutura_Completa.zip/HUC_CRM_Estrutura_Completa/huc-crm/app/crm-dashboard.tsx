"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

const PUBLIC_SITE_URL = "https://hucstudios.herotx6.chatgpt.site";

type Lead = {
  id: number;
  name: string;
  email: string;
  company: string;
  project: string;
  plan: string;
  period: string;
  status: string;
  assignedTo: string;
  notes: string;
  source: string;
  qualityScore: number;
  validationStatus: string;
  validationDetails: string;
  validationNotes: string;
  duplicateOfId: number | null;
  validatedAt: string | null;
  validatedBy: string;
  notificationStatus: string;
  notificationError: string;
  notifiedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type Collaborator = {
  id: number | string;
  name: string;
  email: string;
  role: "owner" | "admin" | "atendimento";
  active: boolean;
  source: "system" | "custom";
};

const statusOptions = [
  ["novo", "Novo"],
  ["em_contato", "Em contato"],
  ["proposta", "Proposta enviada"],
  ["fechado", "Fechado"],
  ["arquivado", "Arquivado"],
] as const;

const validationOptions = [
  ["qualificado", "Qualificado"],
  ["revisar", "Revisar"],
  ["duplicado", "Duplicado"],
  ["descartado", "Descartado"],
] as const;

const statusLabels = Object.fromEntries(statusOptions) as Record<string, string>;
const validationLabels = Object.fromEntries(validationOptions) as Record<string, string>;
const roleLabels = { owner: "Proprietário", admin: "Administrador", atendimento: "Atendimento" };

function asDate(value: string) {
  return new Date(value.includes("T") ? value : `${value.replace(" ", "T")}Z`);
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
    timeZone: "America/Sao_Paulo",
  }).format(asDate(value));
}

function validationDetails(value: string) {
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export function AdminDashboard({
  viewerName,
  viewerEmail,
  viewerRole,
  canManageTeam,
  signOutUrl,
}: {
  viewerName: string;
  viewerEmail: string;
  viewerRole: "owner" | "admin" | "atendimento";
  canManageTeam: boolean;
  signOutUrl: string;
}) {
  const [view, setView] = useState<"leads" | "team">("leads");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ativos");
  const [validationFilter, setValidationFilter] = useState("todos");
  const [assigneeFilter, setAssigneeFilter] = useState("todos");
  const [planFilter, setPlanFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("todos");
  const [sortBy, setSortBy] = useState("recentes");
  const [filterReferenceTime] = useState(() => Date.now());
  const [selected, setSelected] = useState<Lead | null>(null);
  const [saving, setSaving] = useState(false);
  const [teamSaving, setTeamSaving] = useState(false);
  const [newMember, setNewMember] = useState({ name: "", email: "", role: "atendimento" });

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [leadsResponse, teamResponse] = await Promise.all([
        fetch("/api/admin/leads", { cache: "no-store" }),
        fetch("/api/admin/collaborators", { cache: "no-store" }),
      ]);
      const leadsData = (await leadsResponse.json()) as { leads?: Lead[]; error?: string };
      const teamData = (await teamResponse.json()) as { collaborators?: Collaborator[]; error?: string };
      if (!leadsResponse.ok) throw new Error(leadsData.error || "Não foi possível carregar os contatos.");
      if (!teamResponse.ok) throw new Error(teamData.error || "Não foi possível carregar a equipe.");
      setLeads(leadsData.leads || []);
      setCollaborators(teamData.collaborators || []);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Não foi possível carregar o CRM.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => { void loadData(); }, 0);
    return () => window.clearTimeout(timer);
  }, [loadData]);

  const plans = useMemo(() => Array.from(new Set(leads.map((lead) => lead.plan))).sort(), [leads]);
  const activeAssignees = useMemo(
    () => Array.from(new Set(collaborators.filter((member) => member.active).map((member) => member.name))).sort(),
    [collaborators],
  );

  const filtered = useMemo(() => {
    const normalized = query.toLowerCase().trim();
    const now = filterReferenceTime;
    const referenceDate = new Date(filterReferenceTime);
    const dateLimit = dateFilter === "hoje"
      ? Date.UTC(referenceDate.getUTCFullYear(), referenceDate.getUTCMonth(), referenceDate.getUTCDate())
      : dateFilter === "7d" ? now - 7 * 24 * 60 * 60 * 1000
        : dateFilter === "30d" ? now - 30 * 24 * 60 * 60 * 1000 : 0;

    const rows = leads.filter((lead) => {
      const matchesStatus = statusFilter === "todos"
        || (statusFilter === "ativos" && lead.status !== "arquivado")
        || lead.status === statusFilter;
      const matchesValidation = validationFilter === "todos" || lead.validationStatus === validationFilter;
      const matchesAssignee = assigneeFilter === "todos" || lead.assignedTo === assigneeFilter;
      const matchesPlan = planFilter === "todos" || lead.plan === planFilter;
      const matchesDate = dateLimit === 0 || asDate(lead.createdAt).getTime() >= dateLimit;
      const haystack = `${lead.name} ${lead.email} ${lead.company} ${lead.plan} ${lead.project} ${lead.assignedTo}`.toLowerCase();
      return matchesStatus && matchesValidation && matchesAssignee && matchesPlan && matchesDate && (!normalized || haystack.includes(normalized));
    });

    return rows.sort((left, right) => {
      if (sortBy === "antigos") return asDate(left.createdAt).getTime() - asDate(right.createdAt).getTime();
      if (sortBy === "qualidade") return right.qualityScore - left.qualityScore || right.id - left.id;
      if (sortBy === "atualizados") return asDate(right.updatedAt).getTime() - asDate(left.updatedAt).getTime();
      return asDate(right.createdAt).getTime() - asDate(left.createdAt).getTime();
    });
  }, [assigneeFilter, dateFilter, filterReferenceTime, leads, planFilter, query, sortBy, statusFilter, validationFilter]);

  const stats = useMemo(() => ({
    novos: leads.filter((lead) => lead.status === "novo").length,
    andamento: leads.filter((lead) => ["em_contato", "proposta"].includes(lead.status)).length,
    qualificados: leads.filter((lead) => lead.validationStatus === "qualificado").length,
    revisar: leads.filter((lead) => ["revisar", "duplicado"].includes(lead.validationStatus)).length,
  }), [leads]);

  const filtersActive = query || statusFilter !== "ativos" || validationFilter !== "todos"
    || assigneeFilter !== "todos" || planFilter !== "todos" || dateFilter !== "todos" || sortBy !== "recentes";

  function clearFilters() {
    setQuery("");
    setStatusFilter("ativos");
    setValidationFilter("todos");
    setAssigneeFilter("todos");
    setPlanFilter("todos");
    setDateFilter("todos");
    setSortBy("recentes");
  }

  async function updateLead(id: number, changes: Partial<Pick<Lead, "status" | "assignedTo" | "notes" | "validationStatus" | "validationNotes">>) {
    setSaving(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/admin/leads", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id, ...changes }),
      });
      const data = (await response.json()) as { lead?: Lead; error?: string };
      if (!response.ok || !data.lead) throw new Error(data.error || "Não foi possível salvar.");
      setLeads((current) => current.map((lead) => lead.id === id ? data.lead! : lead));
      setSelected(data.lead);
      setNotice("Alterações salvas.");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Não foi possível salvar.");
    } finally {
      setSaving(false);
    }
  }

  async function addCollaborator(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setTeamSaving(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/admin/collaborators", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(newMember),
      });
      const data = (await response.json()) as { collaborator?: Collaborator; error?: string };
      if (!response.ok || !data.collaborator) throw new Error(data.error || "Não foi possível adicionar o colaborador.");
      setCollaborators((current) => [...current.filter((member) => member.email !== data.collaborator!.email), data.collaborator!]);
      setNewMember({ name: "", email: "", role: "atendimento" });
      setNotice(`${data.collaborator.name} já pode entrar no CRM com esse e-mail.`);
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Não foi possível adicionar o colaborador.");
    } finally {
      setTeamSaving(false);
    }
  }

  async function updateCollaborator(member: Collaborator, changes: { role?: string; active?: boolean }) {
    if (member.source !== "custom" || typeof member.id !== "number") return;
    setTeamSaving(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/admin/collaborators", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: member.id, ...changes }),
      });
      const data = (await response.json()) as { collaborator?: Collaborator; error?: string };
      if (!response.ok || !data.collaborator) throw new Error(data.error || "Não foi possível alterar o acesso.");
      setCollaborators((current) => current.map((item) => item.id === member.id ? data.collaborator! : item));
      setNotice("Acesso do colaborador atualizado.");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Não foi possível alterar o acesso.");
    } finally {
      setTeamSaving(false);
    }
  }

  return (
    <main className="admin-shell">
      <aside className="admin-sidebar">
        <a className="admin-brand" href={PUBLIC_SITE_URL}><span>H</span><strong>HUC CRM</strong></a>
        <nav aria-label="Painel administrativo">
          <button className={view === "leads" ? "active" : ""} type="button" onClick={() => setView("leads")}><span>◈</span> Oportunidades</button>
          <button className={view === "team" ? "active" : ""} type="button" onClick={() => setView("team")}><span>◎</span> Equipe</button>
          <a href={PUBLIC_SITE_URL} target="_blank" rel="noreferrer"><span>↗</span> Ver site</a>
        </nav>
        <div className="admin-user">
          <span>{viewerName.slice(0, 1).toUpperCase()}</span>
          <div><strong>{viewerName}</strong><small>{roleLabels[viewerRole]} · {viewerEmail}</small></div>
          <a href={signOutUrl} target="_top" aria-label="Sair">⇥</a>
        </div>
      </aside>

      <section className="admin-main">
        <header className="admin-header">
          <div>
            <p>HUC STUDIOS // CENTRAL</p>
            <h1>{view === "leads" ? "Oportunidades" : "Equipe"}</h1>
            <span>{view === "leads" ? "Priorize, valide e acompanhe cada contato até o fechamento." : "Controle quem pode acessar o CRM e o nível de permissão de cada pessoa."}</span>
          </div>
          <button className="admin-refresh" type="button" onClick={() => void loadData()} disabled={loading}>↻ Atualizar</button>
        </header>

        {error && <div className="admin-alert" role="alert">{error}</div>}
        {notice && <div className="admin-notice" role="status">{notice}</div>}

        {view === "leads" ? (
          <>
            <div className="admin-stats">
              <article className="stat-new"><span>Novos</span><strong>{stats.novos}</strong><small>aguardando atendimento</small></article>
              <article className="stat-progress"><span>Em andamento</span><strong>{stats.andamento}</strong><small>contato ou proposta</small></article>
              <article className="stat-won"><span>Qualificados</span><strong>{stats.qualificados}</strong><small>dados com boa qualidade</small></article>
              <article className="stat-review"><span>Pedem revisão</span><strong>{stats.revisar}</strong><small>incompletos ou duplicados</small></article>
            </div>

            <div className="admin-toolbar">
              <label className="search-field"><span>Buscar</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Nome, e-mail, empresa, projeto ou responsável" /></label>
              <label><span>Status comercial</span><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="ativos">Contatos ativos</option><option value="todos">Todos</option>{statusOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
              <label><span>Validação</span><select value={validationFilter} onChange={(event) => setValidationFilter(event.target.value)}><option value="todos">Todas</option>{validationOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
              <label><span>Responsável</span><select value={assigneeFilter} onChange={(event) => setAssigneeFilter(event.target.value)}><option value="todos">Todos</option><option value="Não atribuído">Não atribuído</option>{activeAssignees.map((name) => <option value={name} key={name}>{name}</option>)}</select></label>
              <label><span>Plano</span><select value={planFilter} onChange={(event) => setPlanFilter(event.target.value)}><option value="todos">Todos</option>{plans.map((plan) => <option value={plan} key={plan}>{plan}</option>)}</select></label>
              <label><span>Período</span><select value={dateFilter} onChange={(event) => setDateFilter(event.target.value)}><option value="todos">Qualquer data</option><option value="hoje">Hoje</option><option value="7d">Últimos 7 dias</option><option value="30d">Últimos 30 dias</option></select></label>
              <label><span>Ordenar</span><select value={sortBy} onChange={(event) => setSortBy(event.target.value)}><option value="recentes">Mais recentes</option><option value="antigos">Mais antigos</option><option value="qualidade">Maior qualidade</option><option value="atualizados">Atualizados recentemente</option></select></label>
              <div className="filter-summary"><strong>{filtered.length}</strong><span>de {leads.length} contatos</span><button type="button" onClick={clearFilters} disabled={!filtersActive}>Limpar filtros</button></div>
            </div>

            {loading ? (
              <div className="admin-empty">Carregando oportunidades...</div>
            ) : filtered.length === 0 ? (
              <div className="admin-empty"><strong>Nenhum contato encontrado.</strong><span>Ajuste ou limpe os filtros para ampliar os resultados.</span></div>
            ) : (
              <div className="lead-table-wrap">
                <table className="lead-table">
                  <thead><tr><th>Contato</th><th>Interesse</th><th>Qualidade</th><th>Status</th><th>Responsável</th><th>Recebido</th><th /></tr></thead>
                  <tbody>{filtered.map((lead) => (
                    <tr key={lead.id}>
                      <td><strong>{lead.name}</strong><a href={`mailto:${lead.email}`}>{lead.email}</a><small>{lead.company || "Sem empresa informada"}</small></td>
                      <td><strong>{lead.plan}</strong><span>{lead.project}</span></td>
                      <td><span className={`quality-badge quality-${lead.validationStatus}`}><b>{lead.qualityScore || "—"}</b><small>{validationLabels[lead.validationStatus] || "Revisar"}</small></span></td>
                      <td><span className={`lead-status status-${lead.status}`}>{statusLabels[lead.status] || lead.status}</span></td>
                      <td>{lead.assignedTo}</td>
                      <td>{formatDate(lead.createdAt)}</td>
                      <td><button type="button" onClick={() => setSelected(lead)}>Abrir</button></td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            )}
          </>
        ) : (
          <div className="team-layout">
            {canManageTeam && (
              <form className="team-add-card" onSubmit={(event) => void addCollaborator(event)}>
                <div><span>ADICIONAR ACESSO</span><h2>Novo colaborador</h2><p>Use exatamente o e-mail da conta ChatGPT que a pessoa utilizará para entrar.</p></div>
                <label>Nome<input required minLength={2} maxLength={100} value={newMember.name} onChange={(event) => setNewMember({ ...newMember, name: event.target.value })} placeholder="Nome do colaborador" /></label>
                <label>E-mail<input required type="email" maxLength={180} value={newMember.email} onChange={(event) => setNewMember({ ...newMember, email: event.target.value })} placeholder="nome@empresa.com" /></label>
                <label>Nível de acesso<select value={newMember.role} onChange={(event) => setNewMember({ ...newMember, role: event.target.value })}><option value="atendimento">Atendimento — gerencia leads</option><option value="admin">Administrador — gerencia leads e equipe</option></select></label>
                <button type="submit" disabled={teamSaving}>{teamSaving ? "Salvando..." : "+ Adicionar colaborador"}</button>
              </form>
            )}

            <section className="team-list-card">
              <header><div><span>EQUIPE AUTORIZADA</span><h2>{collaborators.filter((member) => member.active).length} acessos ativos</h2></div>{!canManageTeam && <small>Somente administradores podem alterar acessos.</small>}</header>
              {loading ? <div className="admin-empty">Carregando equipe...</div> : (
                <div className="team-list">
                  {collaborators.map((member) => (
                    <article className={!member.active ? "inactive" : ""} key={member.id}>
                      <div className="member-avatar">{member.name.slice(0, 1).toUpperCase()}</div>
                      <div className="member-identity"><strong>{member.name} {member.email === viewerEmail.toLowerCase() && <em>Você</em>}</strong><span>{member.email}</span></div>
                      <div className="member-access">
                        {member.source === "custom" && canManageTeam ? (
                          <select value={member.role} onChange={(event) => void updateCollaborator(member, { role: event.target.value })} disabled={teamSaving} aria-label={`Nível de acesso de ${member.name}`}><option value="atendimento">Atendimento</option><option value="admin">Administrador</option></select>
                        ) : <span className={`role-badge role-${member.role}`}>{roleLabels[member.role]}</span>}
                        {member.source === "custom" && canManageTeam ? (
                          <button className={member.active ? "deactivate" : "activate"} type="button" disabled={teamSaving} onClick={() => void updateCollaborator(member, { active: !member.active })}>{member.active ? "Desativar" : "Reativar"}</button>
                        ) : <small>{member.active ? "Ativo" : "Inativo"}</small>}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </section>

      {selected && (
        <div className="lead-drawer-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null); }}>
          <section className="lead-drawer" role="dialog" aria-modal="true" aria-labelledby="lead-title">
            <header><div><span>CONTATO #{selected.id}</span><h2 id="lead-title">{selected.name}</h2></div><button type="button" onClick={() => setSelected(null)} aria-label="Fechar">×</button></header>

            <div className={`validation-card quality-${selected.validationStatus}`}>
              <div className="validation-score"><strong>{selected.qualityScore || "—"}</strong><span>{selected.qualityScore ? "/ 100" : "sem nota"}</span></div>
              <div><span>ANÁLISE DO CADASTRO</span><h3>{validationLabels[selected.validationStatus] || "Revisar"}</h3><p>{validationDetails(selected.validationDetails).length ? validationDetails(selected.validationDetails).join(" · ") : selected.qualityScore ? "Os dados informados passaram pelos critérios automáticos." : "Contato anterior à análise automática. Faça uma revisão manual."}</p>{selected.duplicateOfId && <a href={`#lead-${selected.duplicateOfId}`}>Possível duplicata do contato #{selected.duplicateOfId}</a>}</div>
            </div>

            <div className="lead-contact-grid"><div><span>E-mail</span><a href={`mailto:${selected.email}`}>{selected.email}</a></div><div><span>Instagram ou empresa</span><strong>{selected.company || "Não informado"}</strong></div><div><span>Plano</span><strong>{selected.plan}</strong></div><div><span>Melhor período</span><strong>{selected.period}</strong></div><div><span>Notificação da equipe</span><strong><span className={`lead-status ${selected.notificationStatus === "sent" ? "status-fechado" : selected.notificationStatus === "failed" ? "status-novo" : "status-arquivado"}`}>{selected.notificationStatus === "sent" ? "E-mail solicitado ✓" : selected.notificationStatus === "failed" ? "Falha no e-mail" : "Registro anterior"}</span></strong></div></div>
            <div className="lead-project"><span>Objetivo do projeto</span><p>{selected.project}</p></div>
            <div className="lead-controls">
              <label>Status comercial<select value={selected.status} onChange={(event) => void updateLead(selected.id, { status: event.target.value })} disabled={saving}>{statusOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
              <label>Responsável<select value={selected.assignedTo} onChange={(event) => void updateLead(selected.id, { assignedTo: event.target.value })} disabled={saving}><option>Não atribuído</option>{!activeAssignees.includes(selected.assignedTo) && selected.assignedTo !== "Não atribuído" && <option>{selected.assignedTo}</option>}{activeAssignees.map((name) => <option value={name} key={name}>{name}</option>)}</select></label>
              <label>Validação<select value={selected.validationStatus} onChange={(event) => void updateLead(selected.id, { validationStatus: event.target.value })} disabled={saving}>{validationOptions.map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></label>
            </div>
            <label className="lead-notes">Anotações comerciais<textarea value={selected.notes} onChange={(event) => setSelected({ ...selected, notes: event.target.value })} placeholder="Registre retornos, valores ou próximos passos..." /><button type="button" onClick={() => void updateLead(selected.id, { notes: selected.notes })} disabled={saving}>{saving ? "Salvando..." : "Salvar anotações"}</button></label>
            <label className="lead-notes validation-notes">Parecer da validação<textarea value={selected.validationNotes} onChange={(event) => setSelected({ ...selected, validationNotes: event.target.value })} placeholder="Explique por que o lead foi qualificado, revisado ou descartado..." /><button type="button" onClick={() => void updateLead(selected.id, { validationNotes: selected.validationNotes })} disabled={saving}>{saving ? "Salvando..." : "Salvar parecer"}</button></label>
            <footer><span>Recebido em {formatDate(selected.createdAt)}{selected.validatedBy ? ` · validado por ${selected.validatedBy}` : ""}</span><a href={`mailto:${selected.email}?subject=${encodeURIComponent(`HUC Studios — retorno sobre ${selected.plan}`)}`}>Responder por e-mail ↗</a></footer>
          </section>
        </div>
      )}
    </main>
  );
}
