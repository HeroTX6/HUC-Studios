import { chatGPTSignOutPath, requireChatGPTUser } from "@/app/chatgpt-auth";
import { authorizeCrmUser, canManageTeam } from "@/lib/admin-auth";
import { AdminDashboard } from "./crm-dashboard";
import "./crm.css";

export const dynamic = "force-dynamic";

const PUBLIC_SITE_URL = "https://hucstudios.herotx6.chatgpt.site";

export default async function CrmPage() {
  const identity = await requireChatGPTUser("/");
  const user = await authorizeCrmUser(identity);

  if (!user) {
    return (
      <main className="admin-shell admin-denied">
        <div className="admin-denied-card">
          <span>HUC CRM // ACESSO RESTRITO</span>
          <h1>Este e-mail não faz parte da equipe.</h1>
          <p>Você entrou como <strong>{identity.email}</strong>. Peça a um administrador para adicionar este e-mail à equipe.</p>
          <a className="admin-button" href={chatGPTSignOutPath("/")} target="_top">Trocar de conta</a>
          <a className="admin-back" href={PUBLIC_SITE_URL}>Voltar ao site da HUC</a>
        </div>
      </main>
    );
  }

  return (
    <AdminDashboard
      viewerName={user.memberName || user.displayName}
      viewerEmail={user.email}
      viewerRole={user.role}
      canManageTeam={canManageTeam(user.role)}
      signOutUrl={chatGPTSignOutPath("/")}
    />
  );
}
