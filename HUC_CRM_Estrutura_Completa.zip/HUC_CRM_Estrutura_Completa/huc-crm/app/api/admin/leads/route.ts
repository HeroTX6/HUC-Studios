import { getCrmUser } from "@/lib/admin-auth";
import { requestHuc } from "@/lib/huc-api";

export async function GET() {
  if (!(await getCrmUser())) {
    return Response.json({ error: "Acesso não autorizado." }, { status: 403 });
  }
  return requestHuc("/api/crm/leads", "GET");
}

export async function PATCH(request: Request) {
  const user = await getCrmUser();
  if (!user) {
    return Response.json({ error: "Acesso não autorizado." }, { status: 403 });
  }

  try {
    const payload = (await request.json()) as Record<string, unknown>;
    if (payload.validationStatus !== undefined || payload.validationNotes !== undefined) {
      payload.validatedBy = user.email;
    }
    return requestHuc("/api/crm/leads", "PATCH", JSON.stringify(payload));
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }
}
