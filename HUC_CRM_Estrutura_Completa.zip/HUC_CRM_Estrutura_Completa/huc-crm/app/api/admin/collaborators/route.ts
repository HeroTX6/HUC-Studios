import { canManageTeam, getCrmUser } from "@/lib/admin-auth";
import { requestHuc } from "@/lib/huc-api";

export async function GET() {
  if (!(await getCrmUser())) {
    return Response.json({ error: "Acesso não autorizado." }, { status: 403 });
  }
  return requestHuc("/api/crm/collaborators", "GET");
}

export async function POST(request: Request) {
  const user = await getCrmUser();
  if (!user || !canManageTeam(user.role)) {
    return Response.json({ error: "Apenas administradores podem adicionar colaboradores." }, { status: 403 });
  }

  try {
    return requestHuc("/api/crm/collaborators", "POST", JSON.stringify(await request.json()));
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const user = await getCrmUser();
  if (!user || !canManageTeam(user.role)) {
    return Response.json({ error: "Apenas administradores podem alterar colaboradores." }, { status: 403 });
  }

  try {
    return requestHuc("/api/crm/collaborators", "PATCH", JSON.stringify(await request.json()));
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }
}
