import { env } from "cloudflare:workers";

const HUC_SITE_URL = "https://hucstudios.herotx6.chatgpt.site";

function serviceToken() {
  const value = (env as unknown as Record<string, unknown>).HUC_CRM_SERVICE_TOKEN;
  return typeof value === "string" ? value : "";
}

export async function requestHuc(path: string, method: "GET" | "POST" | "PATCH", body?: string) {
  const token = serviceToken();
  if (token.length < 32) {
    return Response.json({ error: "A conexão com a HUC Studios ainda não foi configurada." }, { status: 503 });
  }

  try {
    const response = await fetch(`${HUC_SITE_URL}${path}`, {
      method,
      cache: "no-store",
      headers: {
        authorization: `Bearer ${token}`,
        ...(body ? { "content-type": "application/json" } : {}),
      },
      body,
    });
    return new Response(await response.text(), {
      status: response.status,
      headers: {
        "content-type": response.headers.get("content-type") || "application/json; charset=utf-8",
        "cache-control": "no-store",
      },
    });
  } catch {
    return Response.json({ error: "Não foi possível conectar ao banco da HUC Studios." }, { status: 502 });
  }
}
