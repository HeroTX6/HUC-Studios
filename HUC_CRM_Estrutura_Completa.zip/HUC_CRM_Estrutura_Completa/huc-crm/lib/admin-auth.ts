import { getChatGPTUser, type ChatGPTUser } from "@/app/chatgpt-auth";
import { requestHuc } from "@/lib/huc-api";

export type CrmRole = "owner" | "admin" | "atendimento";

export type CrmUser = ChatGPTUser & {
  memberName: string;
  role: CrmRole;
};

const FALLBACK_MEMBERS: Record<string, { memberName: string; role: CrmRole }> = {
  "herotx6@gmail.com": { memberName: "Hero", role: "owner" },
  "hucstudios.contato@gmail.com": { memberName: "HUC Studios", role: "owner" },
  "erik.hucstudios@gmail.com": { memberName: "Erik", role: "atendimento" },
};

export async function authorizeCrmUser(user: ChatGPTUser): Promise<CrmUser | null> {
  const email = user.email.trim().toLowerCase();
  try {
    const response = await requestHuc(`/api/crm/session?email=${encodeURIComponent(email)}`, "GET");
    const data = (await response.json()) as {
      authorized?: boolean;
      member?: { name?: string; role?: CrmRole } | null;
    };
    if (response.ok && data.authorized && data.member?.role) {
      return {
        ...user,
        memberName: data.member.name || user.displayName,
        role: data.member.role,
      };
    }
  } catch {
    // The fixed members remain able to recover the CRM if the service is temporarily unavailable.
  }

  const fallback = FALLBACK_MEMBERS[email];
  return fallback ? { ...user, ...fallback } : null;
}

export async function getCrmUser() {
  const user = await getChatGPTUser();
  return user ? authorizeCrmUser(user) : null;
}

export function canManageTeam(role: CrmRole) {
  return role === "owner" || role === "admin";
}
