const CONTACT_INBOX = "hucstudios.contato@gmail.com";
const FORM_SUBMIT_ENDPOINT = `https://formsubmit.co/ajax/${CONTACT_INBOX}`;
const SITE_URL = "https://hucstudios.herotx6.chatgpt.site";

type LeadNotification = {
  id: number;
  name: string;
  email: string;
  company: string;
  project: string;
  plan: string;
  period: string;
};

export async function sendLeadNotification(lead: LeadNotification) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);

  try {
    const response = await fetch(FORM_SUBMIT_ENDPOINT, {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
        origin: SITE_URL,
        referer: `${SITE_URL}/`,
      },
      body: JSON.stringify({
        _subject: `Novo contato HUC Studios — ${lead.plan}`,
        _template: "table",
        _captcha: "false",
        _replyto: lead.email,
        "ID no painel": `#${lead.id}`,
        Nome: lead.name,
        "E-mail do interessado": lead.email,
        "Instagram ou empresa": lead.company || "Não informado",
        Plano: lead.plan,
        "Melhor período para contato": lead.period,
        "Objetivo do projeto": lead.project,
      }),
      signal: controller.signal,
    });

    const result = (await response.json().catch(() => null)) as {
      success?: boolean | string;
      message?: string;
    } | null;

    if (!response.ok || result?.success === false || result?.success === "false") {
      throw new Error(result?.message || `Serviço de e-mail respondeu com status ${response.status}.`);
    }

    return { sent: true as const, error: "" };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Falha desconhecida no envio.";
    return { sent: false as const, error: message.slice(0, 500) };
  } finally {
    clearTimeout(timeout);
  }
}
