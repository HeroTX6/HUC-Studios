export type CrmRole = "owner" | "admin" | "atendimento";

export type SystemCrmMember = {
  id: string;
  name: string;
  email: string;
  role: CrmRole;
  active: true;
  source: "system";
};

export const SYSTEM_CRM_MEMBERS: SystemCrmMember[] = [
  { id: "system-hero", name: "Hero", email: "herotx6@gmail.com", role: "owner", active: true, source: "system" },
  { id: "system-huc", name: "HUC Studios", email: "hucstudios.contato@gmail.com", role: "owner", active: true, source: "system" },
  { id: "system-erik", name: "Erik", email: "erik.hucstudios@gmail.com", role: "atendimento", active: true, source: "system" },
];

export function getSystemCrmMember(email: string) {
  const normalized = email.trim().toLowerCase();
  return SYSTEM_CRM_MEMBERS.find((member) => member.email === normalized) || null;
}
