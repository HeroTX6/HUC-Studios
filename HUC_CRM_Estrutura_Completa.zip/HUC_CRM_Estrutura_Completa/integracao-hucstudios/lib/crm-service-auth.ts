import { env } from "cloudflare:workers";

function runtimeSecret() {
  const value = (env as unknown as Record<string, unknown>).HUC_CRM_SERVICE_TOKEN;
  return typeof value === "string" ? value : "";
}

function secureEqual(left: string, right: string) {
  const size = Math.max(left.length, right.length);
  let difference = left.length ^ right.length;
  for (let index = 0; index < size; index += 1) {
    difference |= (left.charCodeAt(index) || 0) ^ (right.charCodeAt(index) || 0);
  }
  return difference === 0;
}

export function isCrmServiceAuthorized(request: Request) {
  const expected = runtimeSecret();
  const authorization = request.headers.get("authorization") || "";
  const supplied = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  return expected.length >= 32 && secureEqual(supplied, expected);
}

export function unauthorizedCrmResponse() {
  return Response.json({ error: "Acesso não autorizado." }, { status: 403 });
}
