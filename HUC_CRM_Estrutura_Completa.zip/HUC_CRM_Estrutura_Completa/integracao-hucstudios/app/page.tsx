import Image from "next/image";
import { ContactExperience } from "./contact-experience";
import { ThemeToggle } from "./theme-toggle";

const benefits = [
  { icon: "◆", title: "Identidade que marca", text: "Conteúdo com personalidade própria para sua marca deixar de parecer só mais uma no feed." },
  { icon: "⚡", title: "Conteúdo estratégico", text: "Design e comunicação trabalhando juntos para chamar atenção e gerar ação." },
  { icon: "↗", title: "Presença constante", text: "Uma rotina visual organizada para você manter sua audiência sempre conectada." },
];

const portfolio = [
  { title: "Tribunal Gamer", category: "Quadro autoral", image: "/portfolio/tribunal-gamer.png", url: "https://www.instagram.com/p/DbdTB5DO1AM/" },
  { title: "Loading Gaming", category: "Identidade de conteúdo", image: "/portfolio/loading-gaming.png", url: "https://www.instagram.com/p/DblOHkxuLwi/" },
  { title: "Humor gamer", category: "Conteúdo de comunidade", image: "/portfolio/meme-gamer.png", url: "https://www.instagram.com/p/DbbSCj0uguY/" },
  { title: "FNAF × Fortnite", category: "Notícia quente", image: "/portfolio/fnaf-fortnite.png", url: "https://www.instagram.com/p/DcUfWRCFCAs/" },
  { title: "Marvel's Wolverine", category: "Notícia gamer", image: "/portfolio/wolverine.png", url: "https://www.instagram.com/p/Db_J3BbOpyL/" },
];

const plans = [
  {
    name: "Essencial",
    tag: "Para começar",
    price: "297",
    color: "green",
    items: ["6 artes mensais", "Legendas personalizadas", "Identidade visual básica", "1 rodada de ajustes", "Entrega organizada", "Suporte durante a entrega"],
  },
  {
    name: "Profissional",
    tag: "Mais escolhido",
    price: "497",
    color: "purple",
    featured: true,
    items: ["10 artes mensais", "1 carrossel mensal", "Legendas estratégicas", "Identidade visual completa", "Calendário de conteúdo", "2 rodadas de ajustes", "Suporte durante a entrega"],
  },
  {
    name: "Executivo",
    tag: "Presença completa",
    price: "897",
    color: "pink",
    items: ["15 artes mensais", "3 carrosséis mensais", "4 stories complementares", "Legendas estratégicas", "Planejamento estratégico", "Identidade visual premium", "Acompanhamento mensal por e-mail", "Prioridade nas entregas", "Até 3 rodadas de ajustes", "Suporte durante a entrega"],
  },
];

export default function Home() {
  return (
    <main>
      <header className="nav-wrap">
        <a className="brand" href="#inicio" aria-label="HUC Studios — página inicial">
          <span className="brand-mark">H</span><span>HUC <b>Studios</b></span>
        </a>
        <nav aria-label="Navegação principal">
          <a href="#trabalhos">Trabalhos</a>
          <a href="#planos">Planos</a>
          <a href="#sobre">Sobre</a>
          <ThemeToggle />
          <a className="nav-cta" href="#planos">Quero crescer</a>
        </nav>
      </header>

      <section className="hero" id="inicio">
        <div className="aurora" aria-hidden="true" />
        <div className="pixel pixel-a" aria-hidden="true" /><div className="pixel pixel-b" aria-hidden="true" />
        <div className="hero-copy">
          <p className="eyebrow"><span /> Conteúdo que não passa despercebido</p>
          <h1>Sua marca merece um <em>universo próprio.</em></h1>
          <p className="hero-text">A HUC Studios cria identidades e conteúdos que transformam ideias em presença, comunidade e resultado — com estratégia, criatividade e uma energia que é só sua.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="#trabalhos">Conheça nosso trabalho <span>↓</span></a>
            <a className="button button-ghost" href="#planos">Ver planos <span>↗</span></a>
          </div>
          <div className="hero-stats"><div><strong>5+</strong><span>formatos criativos</span></div><div><strong>100%</strong><span>conteúdo autoral</span></div><div><strong>HUC</strong><span>identidade própria</span></div></div>
        </div>

        <div className="hero-console" aria-label="Cartão visual da HUC Studios">
          <div className="console-top"><span>HUC_OS</span><span className="status"><i /> ONLINE</span></div>
          <div className="console-logo">H<span>✦</span></div>
          <p>CARREGANDO SUA<br /><strong>PRÓXIMA FASE</strong></p>
          <div className="loading"><i /></div>
          <div className="console-bottom"><span>CREATIVITY</span><span>STRATEGY</span><span>COMMUNITY</span></div>
        </div>
      </section>

      <section className="color-ticker" aria-label="Serviços">
        <div className="ticker-track">
          <span>IDENTIDADE ✦ CONTEÚDO ✦ SOCIAL MEDIA ✦ DESIGN ✦ ESTRATÉGIA ✦ COMUNIDADE ✦ </span>
          <span aria-hidden="true">IDENTIDADE ✦ CONTEÚDO ✦ SOCIAL MEDIA ✦ DESIGN ✦ ESTRATÉGIA ✦ COMUNIDADE ✦ </span>
          <span aria-hidden="true">IDENTIDADE ✦ CONTEÚDO ✦ SOCIAL MEDIA ✦ DESIGN ✦ ESTRATÉGIA ✦ COMUNIDADE ✦ </span>
          <span aria-hidden="true">IDENTIDADE ✦ CONTEÚDO ✦ SOCIAL MEDIA ✦ DESIGN ✦ ESTRATÉGIA ✦ COMUNIDADE ✦ </span>
        </div>
      </section>

      <section className="method">
        <div className="section-heading"><p className="eyebrow"><span /> O upgrade da sua marca</p><h2>Do “só mais um post”<br />ao conteúdo que <em>prende.</em></h2></div>
        <div className="benefit-grid">{benefits.map((benefit) => <article key={benefit.title}><div className="benefit-icon">{benefit.icon}</div><h3>{benefit.title}</h3><p>{benefit.text}</p></article>)}</div>
      </section>

      <section className="story" id="sobre">
        <div className="story-origin" aria-hidden="true">
          <span>ORIGEM // HUC</span>
          <strong>Hero’s<br />Universe<br /><em>Comics</em></strong>
          <i>EVOLUÇÃO CRIATIVA ↗</i>
        </div>
        <div className="story-content">
          <p className="eyebrow light"><span /> Nossa história</p>
          <h2>Começou em um universo.<br />Hoje, ajuda a criar <em>muitos outros.</em></h2>
          <p>A HUC nasceu dentro do universo HeroTX, entre artes, notícias, quadros e a vontade de construir uma presença digital que não parecesse apenas mais uma.</p>
          <p>O nome surgiu como <strong>Hero’s Universe Comics</strong>, um dos primeiros conceitos criativos do projeto. Quando a criação cresceu para conteúdo, design, identidade visual e estratégia, “Comics” deu lugar a “Studios” — preservando a história e abrindo espaço para novas possibilidades.</p>
          <p>O que começou fortalecendo uma marca própria transformou-se no desejo de ajudar criadores e negócios a encontrarem sua identidade. A HUC começou criando para o próprio universo. Agora, ajuda outras pessoas a construírem os seus.</p>
          <blockquote>“Sua marca merece um universo próprio.”</blockquote>
        </div>
        <div className="story-pillars">
          <article><span>01</span><h3>Propósito</h3><p>Dar identidade e presença às boas ideias.</p></article>
          <article><span>02</span><h3>Missão</h3><p>Transformar ideias em conteúdos estratégicos e marcantes.</p></article>
          <article><span>03</span><h3>Valores</h3><p>Criatividade, identidade, compromisso, proximidade e transparência.</p></article>
        </div>
      </section>

      <section className="work" id="trabalhos">
        <div className="work-heading">
          <div><p className="eyebrow light"><span /> Projetos reais</p><h2>Conteúdo em ação.</h2></div>
          <p>Conheça alguns dos formatos criados e publicados no universo HeroTX.</p>
        </div>
        <div className="portfolio-grid">
          {portfolio.map((item, index) => (
            <a className={`work-card work-${index + 1}`} href={item.url} target="_blank" rel="noreferrer" key={item.title} aria-label={`Ver ${item.title} no Instagram`}>
              <Image src={item.image} alt={`Arte de ${item.title} produzida pela HUC Studios`} fill sizes="(max-width: 760px) 100vw, 33vw" />
              <div className="work-overlay"><span>{item.category}</span><h3>{item.title}</h3><b>↗</b></div>
            </a>
          ))}
        </div>
        <div className="proof-note"><span>●</span> Trabalhos reais publicados em <strong>@herotx.tv</strong></div>
      </section>

      <section className="pricing" id="planos">
        <div className="pricing-heading"><p className="eyebrow"><span /> Escolha sua próxima fase</p><h2>Um plano para cada<br /><em>nível de ambição.</em></h2><p>Comece com o necessário ou construa uma presença completa. Você escolhe o ritmo; a HUC Studios cuida da evolução.</p></div>
        <div className="plans-grid">
          {plans.map((plan) => (
            <article className={`plan-card ${plan.featured ? "featured" : ""} ${plan.color}`} key={plan.name}>
              {plan.featured && <div className="popular">MAIS ESCOLHIDO</div>}
              <div className="plan-head"><p>{plan.tag}</p><h3>{plan.name}</h3></div>
              <div className="plan-price"><span>R$</span><strong>{plan.price}</strong><small>/mês</small></div>
              <ul>{plan.items.map(item => <li key={item}><b>✓</b>{item}</li>)}</ul>
              <ContactExperience className="button plan-button" plan={plan.name}>Quero o {plan.name} <span>↗</span></ContactExperience>
            </article>
          ))}
        </div>
        <p className="pricing-note">Todos os planos podem ser adaptados ao momento e à necessidade da sua marca.</p>
      </section>

      <section className="testimonial-ready">
        <div><p className="eyebrow light"><span /> Confiança se constrói</p><h2>Resultado bom vira<br /><em>história para contar.</em></h2></div>
        <div className="quote-placeholder"><span>“</span><p>Este espaço está preparado para receber os depoimentos reais de quem viver a experiência HUC Studios.</p><small>SEM DEPOIMENTO INVENTADO. SÓ RESULTADO REAL.</small></div>
      </section>

      <section className="final-cta">
        <p>Pronto para apertar o start?</p>
        <h2>Vamos criar algo<br />que seja <em>só seu.</em></h2>
        <ContactExperience className="button button-primary" plan="Personalizado">Conversar com a HUC Studios <span>↗</span></ContactExperience>
      </section>

      <footer><a className="brand footer-brand" href="#inicio"><span className="brand-mark">H</span><span>HUC <b>Studios</b></span></a><p>Ideias com energia. Marcas com presença.</p><p>© 2026 HUC Studios.</p></footer>
    </main>
  );
}
