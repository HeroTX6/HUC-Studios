import { desc, eq, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { leads } from "@/db/schema";
import { sendLeadNotification } from "@/lib/lead-notifications";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PLANS = new Set(["Essencial", "Profissional", "Executivo", "Personalizado"]);
const PERIODS = new Set(["Manhã", "Tarde", "Noite", "Qualquer período"]);

function clean(value: unknown, maxLength: number) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function analyzeLead(input: {
  name: string;
  company: string;
  project: string;
  duplicateOfId: number | null;
}) {
  let score = 100;
  const details: string[] = [];

  if (input.name.split(/\s+/).length < 2) {
    score -= 10;
    details.push("Nome informado com apenas uma palavra");
  }
  if (!input.company) {
    score -= 10;
    details.push("Empresa ou Instagram não informado");
  }
  if (input.project.length < 35) {
    score -= 25;
    details.push("Descrição do projeto muito curta");
  } else if (input.project.length < 70) {
    score -= 10;
    details.push("Descrição do projeto pode ter mais detalhes");
  }
  if (input.duplicateOfId) {
    score -= 45;
    details.push(`E-mail já cadastrado no contato #${input.duplicateOfId}`);
  }

  score = Math.max(0, score);
  return {
    score,
    details,
    status: input.duplicateOfId ? "duplicado" : score >= 75 ? "qualificado" : "revisar",
  };
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Record<string, unknown>;
    if (clean(payload.website, 100)) {
      return Response.json({ ok: true }, { status: 201 });
    }

    const name = clean(payload.name, 120);
    const email = clean(payload.email, 180).toLowerCase();
    const company = clean(payload.company, 180);
    const project = clean(payload.project, 3000);
    const plan = clean(payload.plan, 80);
    const period = clean(payload.period, 80);

    const emailParts = email.split("@");
    const emailIsValid = EMAIL_PATTERN.test(email)
      && !email.includes("..")
      && emailParts[0]?.length <= 64
      && emailParts[1]?.length <= 255;

    if (name.length < 2 || !emailIsValid || project.length < 10 || !PLANS.has(plan) || !PERIODS.has(period)) {
      return Response.json(
        { error: "Confira nome, e-mail, plano, período e descreva o projeto com um pouco mais de detalhe." },
        { status: 400 },
      );
    }

    const db = getDb();
    const [previousLead] = await db
      .select({ id: leads.id })
      .from(leads)
      .where(eq(leads.email, email))
      .orderBy(desc(leads.createdAt), desc(leads.id))
      .limit(1);
    const analysis = analyzeLead({
      name,
      company,
      project,
      duplicateOfId: previousLead?.id || null,
    });
    const notificationClientToken = crypto.randomUUID();
    const [lead] = await db
      .insert(leads)
      .values({
        name,
        email,
        company,
        project,
        plan,
        period,
        qualityScore: analysis.score,
        validationStatus: analysis.status,
        validationDetails: JSON.stringify(analysis.details),
        duplicateOfId: previousLead?.id || null,
        notificationClientToken,
      })
      .returning({ id: leads.id, createdAt: leads.createdAt });

    const notification = await sendLeadNotification({
      id: lead.id,
      name,
      email,
      company,
      project,
      plan,
      period,
    });

    await db
      .update(leads)
      .set({
        notificationStatus: notification.sent ? "sent" : "failed",
        notificationError: notification.error,
        notificationClientToken: notification.sent ? "" : notificationClientToken,
        notifiedAt: notification.sent ? sql`CURRENT_TIMESTAMP` : null,
        updatedAt: sql`CURRENT_TIMESTAMP`,
      })
      .where(eq(leads.id, lead.id));

    if (!notification.sent) {
      console.error("lead-notification-failed", { leadId: lead.id, error: notification.error });
    }

    return Response.json(
      {
        ok: true,
        lead,
        notificationSent: notification.sent,
        notificationClientToken: notification.sent ? undefined : notificationClientToken,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("lead-create-failed", error);
    return Response.json(
      { error: "Não foi possível enviar agora. Tente novamente em instantes." },
      { status: 500 },
    );
  }
}
