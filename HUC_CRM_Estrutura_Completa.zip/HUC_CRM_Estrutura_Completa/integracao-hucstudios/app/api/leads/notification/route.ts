import { and, eq, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { leads } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as { id?: unknown; token?: unknown };
    const id = Number(payload.id);
    const token = typeof payload.token === "string" ? payload.token.trim() : "";

    if (!Number.isInteger(id) || id <= 0 || !/^[0-9a-f-]{36}$/i.test(token)) {
      return Response.json({ error: "Confirmação inválida." }, { status: 400 });
    }

    const db = getDb();
    const [updated] = await db
      .update(leads)
      .set({
        notificationStatus: "sent",
        notificationError: "",
        notificationClientToken: "",
        notifiedAt: sql`CURRENT_TIMESTAMP`,
        updatedAt: sql`CURRENT_TIMESTAMP`,
      })
      .where(and(eq(leads.id, id), eq(leads.notificationClientToken, token)))
      .returning({ id: leads.id });

    if (!updated) {
      return Response.json({ error: "Confirmação expirada ou já utilizada." }, { status: 404 });
    }

    return Response.json({ ok: true });
  } catch (error) {
    console.error("lead-notification-confirmation-failed", error);
    return Response.json({ error: "Não foi possível confirmar a notificação." }, { status: 500 });
  }
}
