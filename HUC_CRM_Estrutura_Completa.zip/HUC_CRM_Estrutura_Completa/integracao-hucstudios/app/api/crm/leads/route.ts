import { and, desc, eq, sql, type SQL } from "drizzle-orm";
import { getDb } from "@/db";
import { crmMembers, leads } from "@/db/schema";
import { isCrmServiceAuthorized, unauthorizedCrmResponse } from "@/lib/crm-service-auth";
import { SYSTEM_CRM_MEMBERS } from "@/lib/crm-members";

const STATUSES = new Set(["novo", "em_contato", "proposta", "fechado", "arquivado"]);
const VALIDATION_STATUSES = new Set(["qualificado", "revisar", "duplicado", "descartado"]);

export async function GET(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  const db = getDb();
  const rows = await db
    .select()
    .from(leads)
    .orderBy(desc(leads.createdAt), desc(leads.id))
    .limit(500);

  return Response.json({ leads: rows }, { headers: { "cache-control": "no-store" } });
}

export async function PATCH(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  let payload: {
    id?: number;
    status?: string;
    assignedTo?: string;
    notes?: string;
    validationStatus?: string;
    validationNotes?: string;
    validatedBy?: string;
  };
  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }

  const id = Number(payload.id);
  if (!Number.isInteger(id) || id <= 0) {
    return Response.json({ error: "Lead inválido." }, { status: 400 });
  }

  const updates: {
    status?: string;
    assignedTo?: string;
    notes?: string;
    validationStatus?: string;
    validationNotes?: string;
    validatedBy?: string;
    validatedAt?: SQL;
    updatedAt: SQL;
  } = { updatedAt: sql`CURRENT_TIMESTAMP` };

  if (payload.status !== undefined) {
    if (!STATUSES.has(payload.status)) return Response.json({ error: "Status inválido." }, { status: 400 });
    updates.status = payload.status;
  }
  if (payload.assignedTo !== undefined) {
    const assignedTo = String(payload.assignedTo).trim().slice(0, 100);
    const systemName = SYSTEM_CRM_MEMBERS.some((member) => member.name === assignedTo);
    let customName = false;
    if (!systemName && assignedTo !== "Não atribuído") {
      const [member] = await getDb()
        .select({ id: crmMembers.id })
        .from(crmMembers)
        .where(and(eq(crmMembers.name, assignedTo), eq(crmMembers.active, true)))
        .limit(1);
      customName = Boolean(member);
    }
    if (assignedTo !== "Não atribuído" && !systemName && !customName) {
      return Response.json({ error: "Responsável inválido ou inativo." }, { status: 400 });
    }
    updates.assignedTo = assignedTo;
  }
  if (payload.notes !== undefined) updates.notes = String(payload.notes).trim().slice(0, 4000);
  if (payload.validationStatus !== undefined) {
    if (!VALIDATION_STATUSES.has(payload.validationStatus)) {
      return Response.json({ error: "Validação inválida." }, { status: 400 });
    }
    updates.validationStatus = payload.validationStatus;
    updates.validatedAt = sql`CURRENT_TIMESTAMP`;
    updates.validatedBy = String(payload.validatedBy || "Equipe HUC").trim().slice(0, 180);
  }
  if (payload.validationNotes !== undefined) {
    updates.validationNotes = String(payload.validationNotes).trim().slice(0, 2000);
    updates.validatedAt = sql`CURRENT_TIMESTAMP`;
    updates.validatedBy = String(payload.validatedBy || "Equipe HUC").trim().slice(0, 180);
  }

  const db = getDb();
  const [updated] = await db.update(leads).set(updates).where(eq(leads.id, id)).returning();
  if (!updated) return Response.json({ error: "Lead não encontrado." }, { status: 404 });

  return Response.json({ lead: updated }, { headers: { "cache-control": "no-store" } });
}
