import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { crmMembers } from "@/db/schema";
import { isCrmServiceAuthorized, unauthorizedCrmResponse } from "@/lib/crm-service-auth";
import { getSystemCrmMember } from "@/lib/crm-members";

export async function GET(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  const email = new URL(request.url).searchParams.get("email")?.trim().toLowerCase() || "";
  const systemMember = getSystemCrmMember(email);
  if (systemMember) {
    return Response.json({ authorized: true, member: systemMember }, { headers: { "cache-control": "no-store" } });
  }

  const [member] = await getDb()
    .select()
    .from(crmMembers)
    .where(eq(crmMembers.email, email))
    .limit(1);

  if (!member?.active) {
    return Response.json({ authorized: false, member: null }, { headers: { "cache-control": "no-store" } });
  }

  return Response.json({
    authorized: true,
    member: { ...member, source: "custom" },
  }, { headers: { "cache-control": "no-store" } });
}
