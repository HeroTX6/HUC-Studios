import { asc, eq, sql, type SQL } from "drizzle-orm";
import { getDb } from "@/db";
import { crmMembers } from "@/db/schema";
import { isCrmServiceAuthorized, unauthorizedCrmResponse } from "@/lib/crm-service-auth";
import { getSystemCrmMember, SYSTEM_CRM_MEMBERS } from "@/lib/crm-members";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ROLES = new Set(["admin", "atendimento"]);

function clean(value: unknown, maxLength: number) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

export async function GET(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  const customMembers = await getDb().select().from(crmMembers).orderBy(asc(crmMembers.name));
  const systemEmails = new Set(SYSTEM_CRM_MEMBERS.map((member) => member.email));
  return Response.json({
    collaborators: [
      ...SYSTEM_CRM_MEMBERS,
      ...customMembers
        .filter((member) => !systemEmails.has(member.email))
        .map((member) => ({ ...member, source: "custom" as const })),
    ],
  }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  let payload: { name?: string; email?: string; role?: string };
  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }

  const name = clean(payload.name, 100);
  const email = clean(payload.email, 180).toLowerCase();
  const role = clean(payload.role, 30);
  if (name.length < 2 || !EMAIL_PATTERN.test(email) || !ROLES.has(role)) {
    return Response.json({ error: "Informe nome, e-mail válido e nível de acesso." }, { status: 400 });
  }
  if (getSystemCrmMember(email)) {
    return Response.json({ error: "Este e-mail já faz parte da equipe principal." }, { status: 409 });
  }

  const db = getDb();
  const [existing] = await db.select({ id: crmMembers.id }).from(crmMembers).where(eq(crmMembers.email, email)).limit(1);
  const [member] = existing
    ? await db.update(crmMembers).set({ name, role, active: true, updatedAt: sql`CURRENT_TIMESTAMP` }).where(eq(crmMembers.id, existing.id)).returning()
    : await db.insert(crmMembers).values({ name, email, role, active: true }).returning();

  return Response.json({ collaborator: { ...member, source: "custom" } }, { status: existing ? 200 : 201 });
}

export async function PATCH(request: Request) {
  if (!isCrmServiceAuthorized(request)) return unauthorizedCrmResponse();

  let payload: { id?: number; name?: string; role?: string; active?: boolean };
  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return Response.json({ error: "Dados inválidos." }, { status: 400 });
  }

  const id = Number(payload.id);
  if (!Number.isInteger(id) || id <= 0) {
    return Response.json({ error: "Colaborador inválido." }, { status: 400 });
  }

  const updates: { name?: string; role?: string; active?: boolean; updatedAt: SQL } = { updatedAt: sql`CURRENT_TIMESTAMP` };
  if (payload.name !== undefined) {
    const name = clean(payload.name, 100);
    if (name.length < 2) return Response.json({ error: "Nome inválido." }, { status: 400 });
    updates.name = name;
  }
  if (payload.role !== undefined) {
    if (!ROLES.has(payload.role)) return Response.json({ error: "Nível de acesso inválido." }, { status: 400 });
    updates.role = payload.role;
  }
  if (payload.active !== undefined) updates.active = Boolean(payload.active);

  const [member] = await getDb().update(crmMembers).set(updates).where(eq(crmMembers.id, id)).returning();
  if (!member) return Response.json({ error: "Colaborador não encontrado." }, { status: 404 });
  return Response.json({ collaborator: { ...member, source: "custom" } });
}
