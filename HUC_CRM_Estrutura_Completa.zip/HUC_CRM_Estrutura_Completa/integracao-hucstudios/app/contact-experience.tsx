"use client";

import { FormEvent, ReactNode, useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

type ContactExperienceProps = {
  plan: string;
  className: string;
  children: ReactNode;
};

const CONTACT_INBOX = "hucstudios.contato@gmail.com";

type ContactValues = {
  name: string;
  email: string;
  company: string;
  project: string;
  period: string;
};

type LeadResponse = {
  error?: string;
  notificationSent?: boolean;
  notificationClientToken?: string;
  lead?: { id: number };
};

async function sendNotificationFromBrowser(
  leadId: number,
  notificationClientToken: string,
  values: ContactValues,
  plan: string,
) {
  const response = await fetch(`https://formsubmit.co/ajax/${CONTACT_INBOX}`, {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      _subject: `Novo contato HUC Studios — ${plan}`,
      _template: "table",
      _captcha: "false",
      _replyto: values.email,
      "ID no painel": `#${leadId}`,
      Nome: values.name,
      "E-mail do interessado": values.email,
      "Instagram ou empresa": values.company || "Não informado",
      Plano: plan,
      "Melhor período para contato": values.period,
      "Objetivo do projeto": values.project,
    }),
  });

  const result = (await response.json().catch(() => null)) as {
    success?: boolean | string;
    message?: string;
  } | null;

  if (!response.ok || result?.success === false || result?.success === "false") {
    throw new Error(result?.message || "O serviço de e-mail não aceitou a notificação.");
  }

  await fetch("/api/leads/notification", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ id: leadId, token: notificationClientToken }),
  });
}

export function ContactExperience({ plan, className, children }: ContactExperienceProps) {
  const [open, setOpen] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => setConnecting(false), 1650);
    return () => window.clearTimeout(timer);
  }, [open]);

  function handleOpenChange(nextOpen: boolean) {
    setOpen(nextOpen);
    if (nextOpen) {
      setConnecting(true);
      setSubmitted(false);
      setError("");
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    setSubmitting(true);
    setError("");
    const data = new FormData(form);
    const values: ContactValues = {
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
      company: String(data.get("company") || ""),
      project: String(data.get("project") || ""),
      period: String(data.get("period") || ""),
    };
    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          plan,
          ...values,
          website: data.get("website"),
        }),
      });
      const result = (await response.json()) as LeadResponse;
      if (!response.ok) throw new Error(result.error || "Não foi possível enviar.");

      if (!result.notificationSent && result.lead?.id && result.notificationClientToken) {
        try {
          await sendNotificationFromBrowser(
            result.lead.id,
            result.notificationClientToken,
            values,
            plan,
          );
        } catch (notificationError) {
          console.error("Não foi possível enviar a notificação por e-mail.", notificationError);
        }
      }

      setSubmitted(true);
      form.reset();
    } catch (submissionError) {
      setError(submissionError instanceof Error ? submissionError.message : "Não foi possível enviar agora.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <button className={className} type="button">{children}</button>
      </DialogTrigger>
      <DialogContent className="contact-dialog">
        {connecting ? (
          <div className="contact-loading" aria-live="polite">
            <div className="contact-signal" aria-hidden="true"><i /><i /><i /></div>
            <p>HUC STUDIOS // ATENDIMENTO</p>
            <DialogTitle>Preparando seu atendimento</DialogTitle>
            <DialogDescription>Conectando você a um representante...</DialogDescription>
            <div className="contact-progress" aria-hidden="true"><span /></div>
          </div>
        ) : submitted ? (
          <div className="contact-success" aria-live="polite">
            <span aria-hidden="true">✓</span>
            <p>CONTATO REGISTRADO</p>
            <DialogTitle>Recebemos seu projeto!</DialogTitle>
            <DialogDescription>As informações já estão com a equipe da HUC Studios. Entraremos em contato pelo e-mail informado.</DialogDescription>
            <button className="button button-primary" type="button" onClick={() => setOpen(false)}>Concluir</button>
          </div>
        ) : (
          <>
            <DialogHeader className="contact-header">
              <p>CONEXÃO ESTABELECIDA <span>●</span></p>
              <DialogTitle>Conte um pouco sobre o projeto.</DialogTitle>
              <DialogDescription>Você escolheu o plano <strong>{plan}</strong>. Preencha os dados e envie sua solicitação diretamente para nossa equipe.</DialogDescription>
            </DialogHeader>
            <form className="contact-form" onSubmit={handleSubmit}>
              <label>Seu nome<Input name="name" required placeholder="Como podemos chamar você?" /></label>
              <label>Seu melhor e-mail<Input name="email" type="email" required placeholder="voce@email.com" /></label>
              <label>Instagram ou empresa<Input name="company" placeholder="@perfil ou nome da marca" /></label>
              <label>Objetivo do projeto<Textarea name="project" required placeholder="Conte o que você quer construir com a HUC Studios..." /></label>
              <label>Melhor período para contato
                <select name="period" required defaultValue="">
                  <option value="" disabled>Selecione um período</option>
                  <option>Manhã</option><option>Tarde</option><option>Noite</option><option>Qualquer período</option>
                </select>
              </label>
              <label className="contact-honeypot" aria-hidden="true">Website<Input name="website" tabIndex={-1} autoComplete="off" /></label>
              {error && <p className="contact-error" role="alert">{error} Se preferir, escreva para <a href="mailto:hucstudios.contato@gmail.com">hucstudios.contato@gmail.com</a>.</p>}
              <button className="button button-primary contact-submit" type="submit" disabled={submitting}>{submitting ? "Enviando..." : "Enviar solicitação"} <span>↗</span></button>
              <small>Seus dados serão usados apenas para responder à sua solicitação.</small>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
