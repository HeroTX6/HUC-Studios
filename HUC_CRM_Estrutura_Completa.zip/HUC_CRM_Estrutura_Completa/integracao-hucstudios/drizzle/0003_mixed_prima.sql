CREATE TABLE `crm_members` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`role` text DEFAULT 'atendimento' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_crm_members_email_unique` ON `crm_members` (`email`);--> statement-breakpoint
CREATE INDEX `idx_crm_members_active_name` ON `crm_members` (`active`,`name`);--> statement-breakpoint
ALTER TABLE `leads` ADD `quality_score` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `validation_status` text DEFAULT 'revisar' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `validation_details` text DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `validation_notes` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `duplicate_of_id` integer;--> statement-breakpoint
ALTER TABLE `leads` ADD `validated_at` text;--> statement-breakpoint
ALTER TABLE `leads` ADD `validated_by` text DEFAULT '' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_leads_validation_created_at` ON `leads` (`validation_status`,`created_at`);--> statement-breakpoint
PRAGMA optimize;
