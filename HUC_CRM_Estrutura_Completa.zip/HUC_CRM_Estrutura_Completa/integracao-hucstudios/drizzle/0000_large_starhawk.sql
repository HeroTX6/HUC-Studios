CREATE TABLE `leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`company` text DEFAULT '' NOT NULL,
	`project` text NOT NULL,
	`plan` text NOT NULL,
	`period` text NOT NULL,
	`status` text DEFAULT 'novo' NOT NULL,
	`assigned_to` text DEFAULT 'Não atribuído' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`source` text DEFAULT 'site' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_leads_status_created_at` ON `leads` (`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_leads_email` ON `leads` (`email`);