ALTER TABLE `leads` ADD `notification_status` text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `notification_error` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `notified_at` text;