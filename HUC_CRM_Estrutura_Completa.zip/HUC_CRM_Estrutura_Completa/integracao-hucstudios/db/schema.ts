import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const leads = sqliteTable(
  "leads",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    name: text("name").notNull(),
    email: text("email").notNull(),
    company: text("company").notNull().default(""),
    project: text("project").notNull(),
    plan: text("plan").notNull(),
    period: text("period").notNull(),
    status: text("status").notNull().default("novo"),
    assignedTo: text("assigned_to").notNull().default("Não atribuído"),
    notes: text("notes").notNull().default(""),
    source: text("source").notNull().default("site"),
    qualityScore: integer("quality_score").notNull().default(0),
    validationStatus: text("validation_status").notNull().default("revisar"),
    validationDetails: text("validation_details").notNull().default("[]"),
    validationNotes: text("validation_notes").notNull().default(""),
    duplicateOfId: integer("duplicate_of_id"),
    validatedAt: text("validated_at"),
    validatedBy: text("validated_by").notNull().default(""),
    notificationStatus: text("notification_status").notNull().default("pending"),
    notificationError: text("notification_error").notNull().default(""),
    notificationClientToken: text("notification_client_token").notNull().default(""),
    notifiedAt: text("notified_at"),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("idx_leads_status_created_at").on(table.status, table.createdAt),
    index("idx_leads_validation_created_at").on(table.validationStatus, table.createdAt),
    index("idx_leads_email").on(table.email),
  ],
);

export const crmMembers = sqliteTable(
  "crm_members",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    name: text("name").notNull(),
    email: text("email").notNull(),
    role: text("role").notNull().default("atendimento"),
    active: integer("active", { mode: "boolean" }).notNull().default(true),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("idx_crm_members_email_unique").on(table.email),
    index("idx_crm_members_active_name").on(table.active, table.name),
  ],
);
